# fpfhough.py
# JM Kinser

import numpy as np
import scipy.fftpack as ft
import mgcreate as mgc
import fpf
import correlate as crr

def CreateFPFHough(alpha=0):
    ## Allocate X
    radii = list(range(10,100,5))
    N = len( radii ) # # of trainers
    V,H = 512,512
    X = np.zeros( (N,V*H), complex )
	## for each circle size
    k = 0
    for r in radii:
        ## Create Image
        circ = mgc.Circle( (V,H), (V/2,H/2), r )
        #circ -= mgc.Circle( (V,H), (V/2,H/2), r-3 )
        fcirc = ft.fft2( circ )
        ## Convert, Load in X
        X[k] = fcirc.ravel()
        k += 1
    ## Create constraint. Phase
    cst = np.zeros( N, complex )
    for i in range( N ):
        theta = float(i)/N * np.pi
        cst[i] = np.cos(theta) + 1j*np.sin(theta)
    ## Create FPF
    ffilt = fpf.FPF( X, cst, alpha )
    ## Return in R space
    ffilt = ffilt.reshape( (V,H) )
    filt = ft.ifft2( ffilt )
    return filt, cst
    
def CorrAnalysis(indata, filt):
    ## Correlate
    corr = crr.Correlate2D( indata, filt )
    ## For each peak
        ## Determine Phase
    ## return Results
    pass 