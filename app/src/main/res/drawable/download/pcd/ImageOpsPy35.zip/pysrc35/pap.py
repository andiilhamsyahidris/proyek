# pap.py

import numpy as np
import mgcreate as mgc
import gnu
import zernike as zer
import scipy.misc as sm
import correlate as crl

#zset = zer.CreateSet(rad)
#orig = sm.imread( 'data/00001684.bmp', flatten=True)

def Correlate( orig, zset ):
    N = len( zset )
    VH = orig.shape
    V,H = VH
    answ = np.zeros((N,V,H) )
    for i in range( len( zset )):
        filt = mgc.Plop( zset[i], VH )
        crr = crl.Correlate2D(256-orig, filt )
        answ[i] = crr.real
    return answ

def Centers():
    # these are h,v
    a = ((207,125), (154,242), (187,214), (224,212),(211,279), (250,240), (258,296), (299,287), (307,236), (297,174), (340,171),(350,221))
    ctrs = []
    for h,v in a:
        ctrs.append( np.array( (v,h) ))
    return ctrs

def PlotJets( crrs, ctrs ):
    for i in range( len( ctrs )):
        v,h = ctrs[i]
        gnu.Save('dud'+str(i)+'.txt', crrs[:,v,h] )


def CorrSpots( crrs, ctrs ):
    # create center window
    V,H = crrs[0].shape
    circs = np.zeros((V,H) )
    for i in range( len( ctrs)):
        circs += mgc.Circle((V,H), ctrs[i], 10 )
    circs = circs > 0.01
    #
    for i in range( len( crrs )):
        sm.imsave( 'dud'+str(i)+'.png', circs * crrs[i] )
        
def Distances( corrs, vec ):
    temp = (corrs.transpose((1,2,0)) - vec )
    temp = temp*temp
    answ = np.sqrt( temp.sum(2))
    return answ
#>>> v,h = ctrs[-1]
#>>> vec = crrs[:,v,h]
#>>> dsts = Distances( crrs, vec )
#>>> sm.imsave( 'dud.png',np.log(dsts+1) )
