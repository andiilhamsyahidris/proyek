# dct2d.py

import numpy as np
import scipy.fftpack as fft

def Parts( VH=(8,8) ):
    answ = []
    x = np.arange( VH{0] )
    y = np.arange( VH{1] )
    for i in range( VH[0] ):
        v1 = np.cos( np.pi/(2*VH[0]) * i * (2*x+1))
        for j in range( VH[1] ):
            v2 = np.cos( np.pi/(2*VH[1]) * j * (2*y+1) )
            mat = np.multiply.outer( v1, v2 )
            answ.append( mat )
    return mat
            

def dct2d( mat ):
    V,H = mat.shape
    temp = np.zeros((V,H))
    for i in range( V ):
        temp[i] = fft.dct( mat[i] )
    answ=np.zeros((V,H))
    for j in range( H ):
        answ[:,j] = fft.dct( temp[:,j] )
    return answ

