# lawstest.py

import os
import texture as txu
import kmeans

def Run( indir ):
    names = os.listdir( indir )
    names = list( map( lambda x: indir+'/'+x, names ))
    jets = txu.ManyJets( names )
    NI,NJ,NF = jets.shape
    alljets = jets.reshape( (NI*NJ,NF) )
    clust, mmb = kmeans.KMeans( NI, alljets )
    return clust, mmb
    
