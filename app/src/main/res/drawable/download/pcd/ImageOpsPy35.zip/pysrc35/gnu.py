# gnu.py
# To read and write GnuPlot files
# JM Kinser
# 1 May 2006

from numpy import zeros

def Save( name, data ):
    # the number of rows
    if len(data.shape)>1:
        (nc,nr) = data.shape
    else :
    	nc = data.shape[0]
    	nr = 1
    fp = open( name, 'w')
    if nr > 1 :
        for i in range(0,nc):
            for j in range(0,nr):
                fp.write( str( data[i,j] ))
                fp.write(' ')
            fp.write('\n')
    else:
        for i in range(0,nc):
            fp.write( str(data[i]) )
            fp.write( '\n' )          
    fp.close()

def Read( name ):
    fp = open( name, 'r' )
    a = fp.readline()
    b = a.split()
    N = len(b)	# horizontal dimension
    dalist = []
    dalist.append( b )
    ok=1
    while ok ==1:
        a=fp.readline()
        b=a.split()
        if len(b)>0:
            dalist.append( b )
        else:
            ok = 0
    M = len( dalist )
    # so far the data is in a list.  convert to an array
    data = zeros( (M,N), float )	# 'd'=Float
    for i in range(0,M):
        for j in range(0,N):
            data[i,j] = float( dalist[i][j] )
    fp.close()
    return data


# Multiplot
def MultiPlot( vecs ):
    N = len( vecs ) # number of vectors
    sz = 1./N
    # save
    for i in range( N ):
        Save('dud'+str(i)+'.txt', vecs[i] )
    # create a string for GnuPLot
    ss = 'set multiplot\n'
    ss += 'set size 1,'+str(sz)+'\n'
    for i in range( N ):
        ss += 'set origin 0,'+str(i*sz)+'\n'
        ss += 'plot "dud'+str(i) +'.txt"\n'
    ss += 'unset multiplot\n'
    ss += 'unset size\n'
    ss += 'unset origin\n'
    return ss
