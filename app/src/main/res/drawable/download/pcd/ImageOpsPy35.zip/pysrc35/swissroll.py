# swissroll.py
# JM Kinser

import numpy as np
import scipy.cluster.vq as clust
import gnu

# create the data file
def MakeRoll( N=1000 ):
    """Number of points
    N = number of data points
    returns matrix"""
    data = np.zeros( (N,2) )
    for i in range( N ):
        r = np.random.rand( 2 )
        theta = 720*r[0] * np.pi/180
        radius = r[0] + (r[1]-0.5)*0.2
        # convert to x-y coords
        x = radius * np.cos( theta )
        y = radius * np.sin( theta )
        data[i] = x,y
    return data

def RunKmeans( data, K ):
    clst, da = clust.kmeans( data,K )
    mmb, db = clust.vq( data, clst )
    return clst, mmb

def CreatePlotFiles( cdata, mmb ):
    for i in range( mmb.max() ):
        z = (mmb==i).nonzero()[0]
        gnu.Save('dud'+str(i)+'.txt', cdata[z] )

# Change data from rectangular coordinates to polar coordinates
def GoPolar( data ):
    N = len( data ) # number of data points
    pdata = np.zeros( (N,2), float )
    for i in range( N ):
        x,y = data[i]
        r = np.sqrt( x*x + y*y )
        theta = np.arctan2( y,x)
        pdata[i] = r, theta
    pdata[:,0] *=10    # scale the radius
    return pdata



