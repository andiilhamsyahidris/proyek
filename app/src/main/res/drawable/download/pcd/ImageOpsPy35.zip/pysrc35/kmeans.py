# kmeans.py
# K-means clustering
# JM Kinser
# 1/6/2007
# 5/17/16

import numpy as np

# Initialization
# initialize with random vectors
def Init1( K, L ):
    """# clusters, Length vectors
    returns matrix of cluster vectors as row"""
    clusts = np.random.ranf( (K,L) )
    return clusts

# initialize with random data vectors
def Init2( K, data ):
    """K=Number of clusters"""
    r = list(range( len(data) ))
    np.random.shuffle( r )
    clusts = data[r[:K]]
    return clusts

# Decide which cluster each vector belongs to
def AssignMembership( clusts, data ):
    NC = len( clusts )
    mmb = []
    for i in range( NC ):
        mmb.append( [] )
    for i in range( len( data )):
        sc = np.zeros( NC )
        for j in range( NC ):
            sc[j] = np.sqrt( ((clusts[j]-data[i])**2 ).sum() )
        mn = sc.argmin()
        mmb[mn].append( i )
    return mmb

# compute the average of the clusters
def ClusterAverage( mmb, data ):
    K = len( mmb )
    N = len( data[0] )
    clusts = np.zeros( (K,N), float )
    for i in range( K ):
        vecs = data[mmb[i]]
        clusts[i] = vecs.mean(0)
    return clusts

# typical driver
def KMeans( K, data ):
    clust1 = Init2( K, data )
    ok = 1
    while ok:
        mmb = AssignMembership( clust1, data )
        clust2 = ClusterAverage( mmb, data )
        diff = ( abs( clust1-clust2) ).sum()
        if diff==0:
            ok = 0
        print ('Difference', diff)
        clust1 = clust2 + 0
    return clust1, mmb

# Measure the variance of a cluster
def ClusterVar( vecs ):
    a = vecs.std( 0 )
    a = (a**2).sum()/len(vecs[0])
    return a

# split a cluster
def Split( mmbi ):
    # mmbi is a single mmb[i]
    m1, m2 = [], []
    N = len( mmbi )
    for i in range( N ):
        r = np.random.rand()
        if r < 0.5:
            m1.append( mmbi[i] )
        else:
            m2.append( mmbi[i] )
    return m1, m2

    
def CData( N, L, scale = 1, K=-1 ):
    # N = number of data vectors
    # L = length of data vectors
    # create a random seeds
    if K==-1:
        K = int( np.random.rand()*N/20 + N/20)
    seeds = np.random.ranf( (K,L) )
    # create random data based on deviations from seeds
    data = np.zeros( (N,L), float )
    for i in range( N ):
        pick = int( np.random.ranf() * K )
        data[i] = seeds[pick] +scale*(0.5*np.random.ranf(L)-0.25)
    return data

