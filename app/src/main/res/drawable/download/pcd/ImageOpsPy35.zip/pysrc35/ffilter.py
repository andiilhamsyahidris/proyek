# ffilter.py
# JM Kinser

import scipy.fftpack as ft
import freq
import mgcreate as mgc

def MaskinF( indata, fmask ):
    fdata = ft.fftshift( ft.fft2( indata ) )
    fdata *= fmask
    answ = ft.ifft2( freq.Swap( fdata ))
    return answ

# multiple wedge filters
def MultiWedges( indata, nwdjs ):
    # nwdjs = number of wedges
    step = 180/nwdjs # angle step
    answ = []
    V,H = indata.shape
    for i in range( nwdjs ):
        angle1 = step * i
        angle2 = angle1 + step
        wedj = mgc.Wedge( (V,H), angle1, angle2 )
        answ.append( abs(MaskinF( indata, wedj )))
    return answ
