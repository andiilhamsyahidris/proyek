# texture.py
# JM Kinser

import os
import numpy as np
import scipy.ndimage as nd
import scipy.stats as st
import scipy.misc as sm
import scipy.signal as ss
import wavelet as wvl


## density of edges
# >>> bdata = nd.gaussian_filter( abs( a - nd.shift(a,(1,1))), 2)

def FourMoments( indir, r=2 ):
    fnames = os.listdir( indir )
    stats = []
    for fn in fnames:
        adata = sm.imread( indir+'/'+ fn, flatten=True )
        bdata = nd.gaussian_filter( abs( adata - nd.shift(adata,(1,1))), r)
        vec = np.zeros( 4 )
        vec[0] = bdata.mean()
        vec[1] = bdata.std()
        vec[2] = st.skew( bdata.ravel() )
        vec[3] = st.kurtosis( bdata.ravel() )
        stats.append( vec )
    stats = np.array( stats )
    return stats, fnames

# ############################################
# GLCM

def Cooccurrence( mat, shift, N):
    # mat should be an int matrix with a max value of N
    p = np.zeros((N,N))
    b = nd.shift( mat, shift )
    for i in range(N):
        for j in range(N):
            p[i,j] = ((mat==i)*(b==j)).sum()
    return p

def HHomogeneity( p ):
    # angular second moment
    return (p*p).sum()

def HContrast( p ):
    N = len(p)
    temp = np.zeros( N )
    for i in range( N ):
        for j in range( N ):
            ndx = abs(i-j)
            temp[ndx] += p[i,j]
    nvec = np.arange( N )**2
    f2 = (nvec * temp).sum()
    return f2

def HCorrelation( p ):
    N = len( p )
    mux = p.sum(1).mean()
    muy = p.sum(0).mean()
    sigx = p.sum(1).std()
    sigy = p.sum(0).std()
    f3 = 0
    for i in range( N ):
        for j in range( N ):
            f3 += ((i+1)*(j+1)*p[i,j] - mux*muy)/(sigx*sigy)
    return f3

def HVariance( p ):
    mu = p.mean()
    N = len(p)
    f4 = 0
    for i in range( N ):
        for j in range( N ):
            f4 += ((i-mu)**2)*p[i,j]
    return f4
        
def HEntropy( p ):
    return -( p * np.log(p+0.00001) ).sum()

def Haralick(p):
    hvec = np.zeros( 5 )
    hvec[0] = HHomogeneity(p)
    hvec[1] = HContrast(p)
    hvec[2] = HCorrelation(p)
    hvec[3] = HVariance(p)
    hvec[4] = HEntropy(p)
    return hvec

def RunHaralick( fnames, shift=(0,1) ):
    NF = len( fnames )
    hmat = np.zeros( (NF,5) )
    for i in range( NF ):
        print( fnames[i] )
        data = sm.imread( fnames[i], flatten=True)
        data = (data/data.max() * 16).astype(int)
        p = Cooccurrence( data, shift, 16)
        hmat[i] = Haralick(p)
    return hmat

## ### ### ### ###  Law's Filters

def BuildLawsFilters( ):
    a = np.array( [[1,4,6,4,1],[-1,-2,0,2,1],[-1,0,2,0,-1],[-1,2,0,-2,1],[1,-4,6,-4,1]])
    laws = []
    for i in range( 5 ):
        for j in range( 5 ):
            laws.append( np.outer( a[i], a[j] ))
    return laws

def LawsJets( indata, NJ=100):
    filts = BuildLawsFilters()
    jets = np.zeros( (NJ,25) )
    corrs = list(map( lambda x: ss.correlate2d( indata, x ), filts ))
    for j in range( 25 ):
        corrs[j] = ss.cspline2d( abs(corrs[j]), 200 )
    corrs = np.array( corrs )
    # extract random jets
    V,H = indata.shape
    vs = np.arange( V )
    hs = np.arange( H )
    np.random.shuffle( vs ); np.random.shuffle( hs )
    for j in range( NJ ):
        jets[j] = corrs[:,vs[j], hs[j] ]+0
    return jets

def ManyJets(  mgnames, NJ = 100 ):
    # allocate for jets
    NI = len( mgnames ) # number of images
    jets = np.zeros( (NI,NJ,25 ))
    # for each image
    for i in range( NI ):
        # load
        print(mgnames[i])
        data = sm.imread( mgnames[i], flatten=True)/255.0
        jets[i] = LawsJets( data )
    return jets
        
# compare with scipy.spatial.distance.cdist
