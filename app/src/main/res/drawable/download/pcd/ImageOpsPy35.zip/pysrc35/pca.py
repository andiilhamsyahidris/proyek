# pca.py
# JM Kinser

import numpy as np
import scipy.misc as sm

def Project( data ):
    """data in rows
    returns matrix: projected data in rows"""
    cv = np.cov( data.transpose() )
    evl, evc = np.linalg.eig( cv )
    ndata = np.dot( data, evc )
    return ndata

def AllDistances( data ):
    """data as rows
    returns vector containing all distances between pairs of points"""
    answ = []
    for i in range( len( data )):
        for j in range( i ):
            answ.append( np.sqrt(((data[i]-data[j])**2).sum()))
    answ = np.array( answ )
    return answ

def EuclidTest( data1, data2 ):
    d1 = AllDistances( data1 )
    d2 = AllDistances( data2 )
    error = abs(d1-d2).sum()
    return error

# ####################################################
# Functions for the Image Scramble Example
# ####################################################

def ScrambleImage( fname ):
    mgdata = sm.imread( fname, flatten=True)
    V, H = mgdata.shape
    ndx = np.arange( V )
    np.random.shuffle( ndx )
    sdata = mgdata[ndx]
    seedrow = list(ndx).index(0)
    return sdata, seedrow

def Unscramble( sdata, seedrow, ndata ):
    V,H = sdata.shape
    udata = np.zeros((V,H))
    udata[0] = sdata[seedrow] + 0
    unused = list( range( V) )
    unused.remove( seedrow )
    nndata = ndata + 0
    k = seedrow
    for i in range( 1, V ):
        dist = np.sqrt(((nndata[k]-nndata[unused])**2).sum(1))
        ag = dist.argsort()
        k = unused[ag[0]]
        udata[i] = sdata[k]
        unused.remove( k )
    return udata

# ####################################################
# Functions for the RGB Example
# ####################################################

def LoadRGBchannels( fname ):
    data = sm.imread( fname )
    r = data[:,:,0]
    g = data[:,:,1]
    b = data[:,:,2]
    return r,g,b

def IsoBlue( r,g,b ):
    # by fractions
    ag = b/(g+1.0)>1.5
    ab = b/(r+1.0)>1.5
    isoblue = ag*ab
    return isoblue
