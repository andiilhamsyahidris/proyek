# gabor.py
# JM Kinser

import numpy as np
import scipy.ndimage as nd
import mgcreate as mgc
import correlate as crr

def GaborCos( VH, f, theta, deltax, deltay ):
    hindex = np.multiply.outer( np.ones(VH[0]), np.arange(VH[1]))- (VH[1]/2)
    vindex = np.multiply.outer( np.arange(VH[0]), np.ones(VH[1]))- (VH[0]/2)
    ct,st = np.cos(theta), np.sin(theta)
    xp = ct * hindex + st * vindex
    yp = -st * hindex + ct * vindex
    cg = np.cos( f * xp )
    t1 = xp*xp/(2. * deltax * deltax)
    t2 = yp*yp/(2.*deltay*deltay)
    t12 = -t1-t2
    while t12.min()<-100: t12 = t12 / 10.
    ans = cg * np.exp(t12)
    return ans

# frange = [0.25, 0.5, 1., 2.]
def Filts( VH, frange ):
    filts = []
    for f in frange:
        for q in range( 8 ):
            theta = q*np.pi/8.
            filts.append( GaborCos( VH, f, theta, 1, 1 ))
    return filts

def ManyCorrelations( indata, filts ):
    VH = indata.shape
    corrs = []
    N = len( filts )
    for i in range( N ):
        f = mgc.Plop( filts[i], VH )
        corrs.append( crr.Correlate2D( indata, f ) )
    return np.array( corrs )
        
def RandomJets( corrs, NJ ):
    # NJ = number of jets 
    N,V,H = corrs.shape
    jets = np.zeros( (NJ,N), corrs.dtype )
    for i in range( NJ ):
        vh = np.random.rand(2)
        v = int( vh[0] * V )
        h = int( vh[1] * H )
        jets[i] = corrs[:,v,h] + 0
    return jets