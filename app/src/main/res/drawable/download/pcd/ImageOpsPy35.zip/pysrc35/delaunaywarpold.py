
# delaunaywarp.py
# JM Kinser

import numpy as np
import scipy.misc as sm
from scipy.spatial import Delaunay
import Image, ImageDraw

# a = Delaunay( fid )
# a.points are the same as fid
# a.vertices: indexes of each triangle
# a.neigbhors.  a.neighbors[k] is list of neighbors of k.  -1 means off frame

def DrawGrid( dela, fid ):
    mg = Image.new( 'L', (512,768) )
    mgd = ImageDraw.Draw( mg )
    for i in range( len( dela.vertices)):
            j,k,l = dela.vertices[i]
            mgd.line( (fid[j][1], fid[j][0], fid[k][1], fid[k][0]), fill=200 )
            mgd.line( (fid[j][1], fid[j][0], fid[l][1], fid[l][0]), fill=200 )
            mgd.line( (fid[l][1], fid[l][0], fid[k][1], fid[k][0]), fill=200 )
    return mg


def Warp( dela, fid, mat1 ):
    # dela = Delaunay for fid1
    # fid: fid2
    V,H = mat1.shape
    mat2 = np.zeros( (V,H) )
    for i in np.xrange( V ):
        if i%25==0: print (i,end='')
        for j in xrange( H ):
            # what triangle
            me = np.array( (i,j) )
            tnum = dela.find_simplex( me ) # which triangle is it in
            v1, v2, v3 = dela.vertices[tnum] # corners
            x1,y1 = dela.points[v1]
            x2, y2 = dela.points[v2]
            r3 = dela.points[v3]
            x3,y3 = r3
            T = np.array( ((x1-x3, x2-x3),((y1-y3),(y2-y3))))
            Ti = np.linalg.inv( T )
            l1, l2 = np.dot( Ti, me-r3)
            l3 = 1 - l1 - l2
            # get point in fa space.
            xx,yy = l1 * fid[v1] + l2*fid[v2] + l3*fid[v3]
            #mat2[xx,yy] = mat1[i,j]
            if 0 <= xx < V and 0 <= yy < H:
                mat2[i,j] = mat1[xx,yy]
    return mat2

def Driver( fname1, fname2, mgname ):
    """fiducial file names"""
    fid1 = ReadDancer( fname1 )
    fid2 = ReadDancer( fname2 )
    mg = sm.imread( mgname, flatten=True)
    dela = Delaunay( fid1 )
    mat3 = Warp( dela, fid2, mg )
    return mat3
