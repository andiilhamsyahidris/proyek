# goshape.py

import scipy.misc as sm
import shape

def FDvectors( indir, fnames ):
    N = len( fnames )
    fvecs = []
    for i in range(N):
        adata = sm.imread( indir+'/'+fnames[i], flatten=True)
        adata = (adata<10).astype(float)
        fvecs.append( shape.FourierDescriptors( adata ))
    # compare
    for i in range( N ):
        print (fvecs[i][:3] )
        print( (abs( fvecs[0]- fvecs[i])).sum())
        
