# mythcluster.py

import numpy as np
import scipy.misc as sm
import scipy.fftpack as ft
import fpf, kmeans

# load three images for training
def LoadThree( indir='data/myth/' ):
    trn = []
    data = sm.imread( indir+'/'+'centaur1.bmp', flatten=True)
    trn.append( (data < 0.5).astype(float) )
    data = sm.imread( indir+'/'+'horse1.bmp', flatten=True)
    trn.append( (data < 0.5).astype(float) )
    data = sm.imread( indir+'/'+'man1.bmp', flatten=True)
    trn.append( (data < 0.5).astype(float) )
    return trn
    
# create three FPFs
def CreateFPFs( trn ):
    cst = np.ones(1)
    alpha = 0.3
    filts = []
    V,H = trn[0].shape
    N = len( trn)
    X = np.zeros( (1,V*H), complex )
    for i in range( N ):
        x = ft.fft2( trn[i])
        X[0] = x.ravel()
        flt = fpf.FPF( X, cst, alpha )
        flt = flt.reshape( (V,H) )*V*H
        filts.append( ft.ifft2(flt) )
    return filts

def Corr2Vector( filts, mg ):
    N = len( filts )
    vec = np.zeros( N )
    for i in range(N) :
        vec[i] = (filts[i]*mg).sum().real
    return vec

# get all images
def TestImages( indir ):
    nms = os.listdir( indir )
    timgs = []
    for n in nms:
        if '.bmp' in n:
            data = sm.imread( indir+'/'+n, flatten=True)
            timgs.append( (data < 0.5).astype(float) )
    return timgs

# correlate all
def CorrAll( filts, timgs ):
    NT = len( timgs )
    NF = len( filts )
    mat = np.zeros((NT,NF) )
    for i in range( NT ):
        mat[i] = Corr2Vector( filts, timgs[i] )
    return mat
    
# cluster by k-means
def KCluster( mat, K ):
    clust, mmb = kmeans.KMeans( K, mat )
    return clust,mmb
    
    
