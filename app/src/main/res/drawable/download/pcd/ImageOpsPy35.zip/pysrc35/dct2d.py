# dct2d.py

import numpy as np
import scipy.fftpack as fft

def Parts( VH=(8,8) ):
    answ = []
    x = np.arange( VH[0] )
    y = np.arange( VH[1] )
    for i in range( VH[0] ):
        v1 = np.cos( np.pi/(2*VH[0]) * i * (2*x+1))
        for j in range( VH[1] ):
            v2 = np.cos( np.pi/(2*VH[1]) * j * (2*y+1) )
            mat = np.multiply.outer( v1, v2 )
            answ.append( mat )
    # 8x8  only
    big = np.zeros( (78,78) )
    k = 0
    for i in range(8 ):
        for j in range( 8 ):
            big[ i*10:i*10+8,j*10:j*10+8] = answ[k] + 0
            k += 1
    return answ, big
            
def dct2d( mat ):
    V,H = mat.shape
    temp = np.zeros((V,H))
    for i in range( V ):
        temp[i] = fft.dct( mat[i] )
    answ=np.zeros((V,H))
    for j in range( H ):
        answ[:,j] = fft.dct( temp[:,j] )
    return answ

def idct2d( mat ):
    V,H = mat.shape
    temp = np.zeros((V,H))
    for i in range( V ):
        temp[i] = fft.idct( mat[i] )
    answ=np.zeros((V,H))
    for j in range( H ):
        answ[:,j] = fft.idct( temp[:,j] )
    return answ
