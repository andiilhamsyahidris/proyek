# gorpolar.py
# JM Kinser

import numpy as np
import scipy.misc as sm
import rpolar as rpl
import mgcreate as mgc

def Square1( dm = 512 ):
    sq = np.zeros( (dm,dm) )
    dm4 = int(dm/4)
    sq[dm4:-dm4,dm4:-dm4] = 1
    rp = rpl.RPolar( sq, (2*dm4,2*dm4) )
    return rp
    
def Square2( dm = 512 ):
    sq = np.zeros( (dm,dm) )
    dm4 = int(dm/4)
    sq[dm4:-dm4,dm4:-dm4] = 1
    rp = rpl.RPolar( sq, (2*dm4-10,2*dm4-30) )
    return rp
    
def Circle1():
    cc = mgc.Circle( (512,512),(256,256), 50 )
    rp = rpl.RPolar( cc, (256,256) )
    return rp
    
def Circle2():
    cc = mgc.Circle( (512,512),(256,256), 50 )
    rp = rpl.RPolar( cc, (240,240) )
    return rp
       
def Oval():
    ov = mgc.Ellipse( (512,512),(256,256),50,100)
    rp = rpl.RPolar( ov, (256,256) )
    return rp

def PapSmear( fname ):
    adata = sm.imread( fname )
    rp = np.zeros( adata.shape )
    rp[:,:,0] = rpl.RPolar( adata[:,:,0], (239,256) )
    rp[:,:,1] = rpl.RPolar( adata[:,:,1], (239,256) )
    rp[:,:,2] = rpl.RPolar( adata[:,:,2], (239,256) )
    return rp

def PapSmear2( fname ):
    adata = sm.imread( fname, flatten=True )
    rp = rpl.RPolar( adata, (239,256) )
    dx,dy = np.gradient( rp )
    return dx[:192]

def PapSmear3( fname, gamma=15 ):
    adata = sm.imread( fname, flatten=True )
    rp = rpl.RPolar( adata, (239,256) )
    dx,dy = np.gradient( rp )
    V,H = rp.shape
    first = []
    for i in range( H ):
        nz = (dx[:,i]>gamma ).nonzero()[0]
        if len(nz)>0:
            if nz[0] < 20 :
                first.append(nz[0] )
    return np.array( first )


