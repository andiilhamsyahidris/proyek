# rpolar.py
# Radial Polar transformations
# JM Kinser

import numpy as np
import scipy.ndimage as nd

def RPolar( data, pxy ):
    """Radius Polar Transormation"""
    ndx = np.indices( data.shape )
    v,h = data.shape
    a = ndx[1].astype( float)
    a = a / h * 2 * np.pi
    y = ndx[0] * np.cos(a)
    x = ndx[0] * np.sin(a)
    ndx[0] = x.astype(int) + pxy[0]
    ndx[1] = y.astype(int) + pxy[1]
    answ = nd.map_coordinates( data, ndx )
    return answ

def IRPolar( rpdata, pxy ):
    """Inverse Radius Polar Transormation"""
    ndx = np.indices( rpdata.shape )
    ndx[0] -= pxy[0]
    ndx[1] -= pxy[1]
    v,h = rpdata.shape
    r = np.sqrt( ndx[0]**2 + ndx[1]**2 )
    theta = np.arctan2( -ndx[0], -ndx[1] )/2/np.pi*h
    ndx[0] = r.astype(int) 
    ndx[1] = theta.astype(int) +h/2 
    answ = nd.map_coordinates( rpdata, ndx )
    answ[pxy[0],pxy[1]:] = answ[pxy[0]-1,pxy[1]:]
    return answ

def LogPolar( data, pxy ):
    """Log Polar Transormation"""
    ndx = np.indices( data.shape )
    v,h = data.shape
    a = ndx[1].astype( float)
    a = a / h * 2 * np.pi
    r = np.exp( ndx[0]/v * np.log(v/2))-1.0
    y = r * np.cos(a)
    x = r * np.sin(a)
    ndx[0] = x.astype(int) + pxy[0]
    ndx[1] = y.astype(int) + pxy[1]
    answ = nd.map_coordinates( data, ndx )
    return answ



