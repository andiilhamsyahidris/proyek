# boat.py
# (c) Copyright JM Kinser 2018
# The Python scripts contained in this file can only be used for educational purposes. All other rights are reserved by the author.

import numpy as np
import scipy.ndimage as nd
import scipy.misc as sm
import correlate as crr

# orig = sm.imread( 'data/boats1.png', flatten=True)

def BuildDock():
    dock = np.zeros((189,545))
    dock[39:46,0:508] = 1
    dock[0:39,9:14] = 1
    dock[46:84,0:5] = 1
    crn = [30,66,100,136,172,206,242,281,315, 349,384,420,456,492]
    for c in crn:
        dock[0:84,c:c+4] = 1
    V,H = dock.shape
    v,h = nd.center_of_mass( dock )
    dock = nd.shift( dock + 0., (V/2-v, H/2-h) )
    return dock

def LocateDock( orig, dock ):
    corr = crr.Correlate2D( orig, dock)
    V,H = corr.shape
    v,h = divmod( abs(corr).argmax(), H )
    return v,h

def Overlay( orig, dock, vh ):
    v,h = vh
    V,H = dock.shape
    ndock = nd.shift( dock, (v-V/2, h-H/2) ) # causes non zero values to appear
    ndock = ndock > 0.1
    return orig + 300*ndock

def SubtractDock( orig, dock, vh ):
    v,h = vh
    V,H = dock.shape
    dock2 = nd.binary_dilation( dock>0.1, iterations=1) 
    ndock = nd.shift( dock2+0., (v-V/2, h-H/2) )
    #ndock = ndock > 0.1
    ndock = (orig -200*ndock)>140
    #lbls, cnt = nd.label( ndock )
    return ndock #lbls

def IDboats( sdock ):
    mask = np.ones( (7,1) )
    answ = nd.binary_dilation( sdock, structure = mask )
    lbl, cnt = nd.label( answ )
    return lbl

