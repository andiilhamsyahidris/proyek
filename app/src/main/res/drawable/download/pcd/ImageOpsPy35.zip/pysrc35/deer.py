# deer.py

import numpy as np
import scipy.misc as sm
import scipy.signal as ss
import scipy.fftpack as ft
import scipy.ndimage as nd
import mgcreate as mgc

def AddNoise( fname ):
    adata = sm.imread(fname,flatten=True)
    noise = np.random.ranf( adata.shape )-0.5
    bdata = adata + 84*noise # 33 percent
    return bdata

def Smoothing( bdata ):
    cdata = ss.cspline2d( bdata, 2 )
    return cdata

def Lopass( bdata ):
    V,H = bdata.shape
    circ = mgc.Circle( (V,H), (V/2,H/2), 128 )
    fbdata = ft.fftshift( ft.fft2( bdata ) )
    fddata = fbdata * circ
    ddata = ft.ifft2( ft.ifftshift( fddata ))
    return ddata.real
    
def ErosionDilation( bdata ):
    b1 = nd.grey_erosion( bdata, 2 )
    b2 = nd.grey_dilation( b1, 4 )
    b3 = nd.grey_erosion( b2, 2 )
    return b3
