# zernike.py
# JM Kinser

import numpy as np
import rpolar

## Zernike
def Zernike( VH, rad, m,n ):
	# rad is radius of sphere
	# R^m _n
	# build this in RPolar space
	rp = np.zeros( VH )
	horz = np.ones(VH[1])
	# radial components
	rr = (np.arange(rad)/float(rad))
	if m==0 and n==0: r = 1
	if abs(m)==1 and n==1: 
		r = rr
	if m==0 and n==2:
		r = 2*(rr**2) -1 
	if abs(m)==2 and n==2:
		r = rr**2
	if abs(m)==1 and n==3:
		r = 3*rr**3 - 2*rr
	if abs(m)==3 and n==3:
		r = rr**3
	if m==0 and n==4:
		r = 6 *rr**4 - 6*rr**2 +1
	if abs(m)==2 and n==4:
		r = 4*rr**4 - 3*rr**2
	if abs(m)==4 and n==4:
		r = rr**4
	if abs(m)==1 and n==5:
		r = 10 *rr**5 - 12* rr**3 + 3*rr
	if abs(m)==3 and n==5:
		r = 5 * rr**5 - 4 * rr**3
	if abs(m)==5 and n==5:
		r = rr**5
	if abs(m)==0 and n==6:
		r = 20*rr**6 - 30*rr**4 + 12*rr**2 - 1
	if abs(m)==2 and n==6:
		r = 15 * rr**6 - 20*rr**4 + 6*rr**2
	if abs(m)==4 and n==6:
		r = 6 *rr**6 - 5*  rr**4
	if abs(m)==6 and n==6:
		r = rr**6
	# 
	rp[:rad] = np.outer(r,horz)
	# cos or sin
	if m <0:
		# odd
		rp *= np.sin( m * np.arange(VH[1]) /float(VH[1]) * 2 *np.pi )
	else:
		rp *= np.cos( m * np.arange(VH[1]) /float(VH[1]) * 2 *np.pi )
	ctr = int(VH[0]/2),int(VH[1]/2)
	answ = rpolar.IRPolar( rp, ctr )
	return answ

def CreateSet():
    VH= (64,64)
    rad = 32
    answ = []
    for n in range( 7 ):
        for m in range(-n,n+1,2):
            print (n,m)
            answ.append( Zernike( VH, rad, m,n ))
    return answ

def BigPicture( zset ):
    # zset from CreateSet
    k=0
    answ = np.zeros((460,494))
    for n in range( 7 ):
        for m in range( -n,n+1,2):
            v = 66*n
            h = int(216- (m/2)*66)
            answ[v:v+64,h:h+64] = zset[k]
            k += 1
    return answ
