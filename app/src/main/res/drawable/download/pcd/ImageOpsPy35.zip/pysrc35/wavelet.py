# wavelet.py
# JM Kinser
# py 3.4
# August 2016

import numpy as np
import scipy.misc as smisc
import scipy.ndimage as nd

def UpPowerOf2( mat ):
    V,H = mat.shape
    vlog, hlog = np.log2( V-1 ), np.log2(H-1)
    vlog, hlog = int(vlog), int(hlog)
    nV, nH = 2**(vlog+1), 2**(hlog+1)
    nmat = np.zeros( (nV, nH) )
    nmat[:V,:H] = mat + 0
    return nmat

def WvlIteration( data ):
    """Single Iteration of Wavelet Decomposition"""
    # data is a 2^ array 
    V,H = data.shape
    V2, H2 = V//2, H//2
    answ = np.zeros( (V,H) )
    vndx = np.arange( 0, V, 2 )
    hndx = np.arange( 0, H, 2 )
    a = data[vndx] + 0
    answ[:V2,:H2] = a[:,hndx] + 0 # UL
    answ[:V2,H2:] = 0.25*abs(nd.sobel(answ[:V2,:H2],0))
    answ[V2:,:H2] = 0.25*abs(nd.sobel(answ[:V2,:H2],1))
    temp = nd.sobel(answ[:V2,:H2],1)
    answ[V2:,H2:] = 0.25*abs(2/3*nd.sobel(answ[:V2,:H2],0) + temp )
    return abs(answ)

def WaveletDecomp( data ):
    # iteratively does the UL corner
    V,H = data.shape
    ans = data+0.0
    v,h = V,H
    ok = True
    while ok:
        # grap data 
        dt = ans[:v,:h] + 0
        b = WvlIteration( dt )
        ans[:v,:h] = b + 0
        v,h = v//2, h//2
        if v<2 or h<2:
            ok = False
    return ans

def GetParts( wvlt ):
    # wvlt is output from RepeatDivide
    V,H = wvlt.shape
    v,h = V//2,H//2
    parts = []
    ok = True
    while ok:
        parts.append( wvlt[:v,h:H] )
        parts.append( wvlt[v:V,:h] )
        parts.append( wvlt[v:V,h:H] )
        V,H = V//2, H//2
        v,h = V//2,H//2
        if v<2 or h<2:
            ok = False
    return parts
    
def WaveletEnergies( parts ):
    vec = np.zeros( len( parts ))
    for i in range(len(parts)):
        v,h = parts[i].shape
        vec[i] = (parts[i]**2).sum()/(v*h)
    return vec

def ExpandParts( parts ):
    # parts from GetParts
    V,H = parts[0].shape
    N = len( parts )
    answ = np.zeros( (N,V,H) )
    for i in range( N//3 ):
        for j in range( 3 ):
            answ[i*3+j] = nd.zoom( parts[i*3+j],2**i)
    return answ
    

