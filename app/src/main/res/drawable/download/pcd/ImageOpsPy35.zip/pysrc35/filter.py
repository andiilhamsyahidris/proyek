# ffilter.py
# JM Kinser

import scipy.fftpack as ft
import freq

def MaskinF( indata, fmask ):
    fdata = freq.Swap( ft.fft2( indata ) )
    fdata *= fmask
    answ = ft.ifft2( freq.Swap( fcirc ))
    return answ