# gaborrun.py

import os
import numpy as np
import scipy.misc as sm
import scipy.signal as ss
import gabor, pca, gnu

def GetNames( indir ):
    a = os.listdir( indir )
    names = []
    for i in a:
        if 'gif' in i:
            names.append( indir + '/' + i )
    names.sort()
    return names

def Run( indir, VH ):
    # get names
    names = GetNames( indir )
    # create filters
    filts = gabor.Filts( VH, [0.25,0.5,1,2] )
    alljets = []
    # for each name 
    for nm in names:
        print( nm )
        # load image
        orig = sm.imread( nm, flatten=True )
        # correlate
        corrs = gabor.ManyCorrelations( orig, filts )
        for c in range(len(corrs)):
            corrs[c] = ss.cspline2d(corrs[c].real, 10 )
        # get jets
        jets = gabor.RandomJets( corrs.real, 100 )
        alljets.extend( jets )
    # PCA
    alljets = np.array( alljets )
    ndata = pca.Project( alljets )
    # plots
    N = len( ndata )
    for i in range( int(N/100) ):
        gnu.Save('plot' + str(i) + '.txt', ndata[i*100:i*100+100] )
    return names
        