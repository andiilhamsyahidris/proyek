# hough.py
# JM Kinser
# July 2016

import numpy as np
import scipy.ndimage as nd
import mgcreate


def LineHough( data, gamma ):
    # gamma is threshold.  Below this value points are not considered
    V,H = data.shape
    R = int(np.sqrt( V*V + H*H ))    
    ho = np.zeros( (R,90), float ) # Hough space
    work = data + 0
    ok = 1
    theta = np.arange( 90 )/180. * np.pi
    tp = np.arange( 90 ).astype(float ) # theta for plotting
    while ok:
        mx = work.max()
        if mx < gamma:
            ok = 0
        else:
            v,h = divmod( work.argmax(), H )
            y = V-v; x = h
            rho = x * np.cos( theta ) + y*np.sin(theta)
            for i in range( len( rho )):
                if 0 <= rho[i] < R and 0<=tp[i]<90:
                    ho[int(rho[i]),int(tp[i])] += mx
            work[v,h] = 0
    return ho

def CircleHough( data, rad, gamma ):
    V,H = data.shape
    ho = np.zeros( (V,H), float )
    mask = mgcreate.Circle( (V,H), (V/2,H/2), rad )
    mask -= mgcreate.Circle( (V,H), (V/2,H/2), rad-1 )
    work = data + 0
    ok = 1
    while ok:
        mx = work.max()
        if mx < gamma: ok = 0
        else:
            v,h = divmod( work.argmax(), H )
            y = V-v; x = h
            ho += nd.shift( mask,(x-V/2,y-H/2))
        work[v,h] = 0
    return ho
