# eigenimage.py
# JM Kinser

import numpy as np
import scipy.misc as sm

def EigenImages( d ):
    N,V,H = d.shape # number of images
    dd = d.astype(float) - d.astype(float).mean(0)
    L = np.zeros( (N,N) )
    for i in range( N ):
        L[i,i] = (dd[i] * dd[i]).sum()
        for j in range( i ):
            L[i,j] = L[j,i] =  (dd[i] * dd[j] ).sum()
    evls, evcs = np.linalg.eig( L )
    emgs = []
    for j in range( N ):
        a = np.zeros( (V,H) )
        for i in range( N ):
            a += evcs[i,j]*dd[i] 
        emgs.append( a/np.sqrt(evls[j]) )
    return emgs, evls

def ProjectEigen( emgs, indata ):
    vec = np.zeros( len( emgs ))
    for i in range( len( emgs )):
        vec[i] = (emgs[i] * indata).sum()
    return vec


# ################ Test
def TestMUG( indir ):
    # load the images
    mg1 = sm.imread( indir +'/gwhite.png', flatten=True)
    mg2 = sm.imread( indir +'/mwhite.png', flatten=True)
    mg3 = sm.imread( indir +'/uwhite.png', flatten=True)
    mgs = np.array([mg1,mg2,mg3])
    print (mgs.shape)
    # compute the eigenimages
    emgs, evls = EigenImages( mgs )
    return emgs, evls
    
