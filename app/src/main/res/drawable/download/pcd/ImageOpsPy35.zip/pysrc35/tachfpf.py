# tachfpf.py
# JM Kinser

import numpy as np
import scipy.misc as sm
import scipy.fftpack as ft
import fpf

def LoadTach( fname ):
    bdata = 1 - sm.imread( fname, flatten=True)/255.
    cuts = []
    vhs = [(303,116), (250, 96), (182,107), (126,150), \
           (104,222), (116,294), (165,343), (231,362), \
           (300,341)]
    for v,h in vhs:
        cuts.append( bdata[v-14:v+14, h-14:h+14] + 0 )
    return bdata, cuts

def MakeTachFPF( cuts, VH ):
    V, H = VH
    NC = len( cuts )
    X = np.zeros( (NC,V*H), complex )
    for i in range( NC ):
        targ = np.zeros( VH )
        vc, hc = cuts[i].shape
        targ[V/2-vc/2:V/2+vc/2, H/2-hc/2:H/2+hc/2] = cuts[i] + 0
        targ = ft.fft2( targ )
        X[i] = targ.ravel()
    cst = np.ones( NC )
    filt = fpf.FPF( X, cst, 0.8 )
    filt = ft.ifft2( filt.reshape( VH ) )
    filt *= V*H
    return filt
    


    

