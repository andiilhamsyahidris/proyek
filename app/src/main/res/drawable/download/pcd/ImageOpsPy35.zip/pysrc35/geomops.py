# geomops.py
# JM Kinser

import numpy as np
import scipy.ndimage as nd

def Bend( data, bend, cvh ):
    """Barrel (bend>1) and Pincushion (0<bend<1)"""
    cv,ch = cvh
    a = np.indices(data.shape)
    V,H = data.shape
    a[0],a[1] = cv-a[0],a[1]-ch
    r = np.sqrt( a[0]*a[0] + a[1]*a[1] )
    t = np.arctan2( a[0], a[1] )
    r = (r ** bend)/(cv**(bend-1))
    x = r* np.cos( t );     y = r* np.sin( t )
    x = x + ch;     y = cv - y
    coords = np.array([y.astype(int),x.astype(int)])
    z = nd.map_coordinates( data, coords )
    return z

def GeoFun( outcoord ):
    a = 10*np.cos( outcoord[0]/10. )+outcoord[0]
    b = 10*np.cos( outcoord[1]/10. )+outcoord[1]
    return a,b

def AffineExample( data ):
    theta = 11 * np.pi/180 # 11 degreess in radians
    mat = np.array( [ [np.cos(theta), -np.sin(theta)], [np.sin(theta/4), np.cos(theta)]] )
    data2 = nd.affine_transform( data, mat )
    return data2
