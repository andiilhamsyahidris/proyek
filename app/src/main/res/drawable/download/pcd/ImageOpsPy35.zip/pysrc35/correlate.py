# correlate.py
# (c) Copyright JM Kinser 2018
# The Python scripts contained in this file can only be used for educational purposes. All other rights are reserved by the author.

import scipy.fftpack as ft

def Correlate1D( A, B ):
    a = ft.fft(A)
    b = ft.fft(B)
    c = a * b.conjugate( )
    C = ft.ifft( c );
    C = ft.fftshift(C);
    return C

def Correlate2D( A, B ):
    a = ft.fft2( A) 
    b = ft.fft2(B)
    c = a * b.conjugate( )
    C = ft.ifft2( c )
    C = ft.fftshift(C)
    return C
    
def Correlate2DF( A, B ):
    c = A * b.conjugate( )
    C = ft.ifft2( c )
    C = ft.fftshift(C)
    return C
