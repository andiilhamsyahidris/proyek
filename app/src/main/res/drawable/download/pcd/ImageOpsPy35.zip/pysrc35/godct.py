# godct.py
# JM Kinser

import numpy as np



    
def DCT1D( vec ):
    N = len( vec )
    x = np.arange( N )
    a = np.zeros( N )
    for i in range( N ):
        a[i] = ( vec * np.cos( np.pi/N*(x+0.5) * i   ) ).sum()
    return a

def IDCT1D( vec ):
    N = len( vec )
    x = np.arange( N )
    a = np.zeros( N )
    for i in range( N ):
        a[i] = ( vec * np.cos( np.pi/N*x * (i+0.5) ) ).sum()
    return a

def DCT2D( mat ):
    V,H = mat.shape
    answ = np.zeros( (V,H) )
    for i in range( V ):
        answ[i] = DCT1D( mat[i] )
    answ2= np.zeros( (V,H) )
    for i in range( H ):
        answ2[:,i] = DCT1D( answ[:,i] )
    return answ2

def Test1():
    x = np.arange( 512 )
    y1 = np.cos( x/32 * np.pi )
    y2 = np.cos( x/64 * np.pi )
    y = y1 + y2
    a = DCT1D( y )
    return y, a

def Test2( vec ):
    a = DCT1D( vec )
    b = IDCT1D( a )
    #scale = vec[0]/np.sqrt(2) # this can't be right
    return a,b
    
