# rgbclust.py
# JM Kinser

import numpy as np
import scipy.misc as sm
import scipy.cluster.vq as clust

def LoadImage( mgname ):
    data = sm.imread( mgname )
    return data

def RandomJets( rgbdata, N ):
    """N= number of jets"""
    jets = []
    V,H,d = rgbdata.shape
    for i in range( N ):
        x = int( H * np.random.rand() )
        y = int( V * np.random.rand() )
        jets.append( rgbdata[y,x] )
    jets = np.array( jets, float )
    return jets

def GoKmeans( jets, K, rgbdata ):
    V,H,d = rgbdata.shape
    clst, dst = clust.kmeans( jets, K )
    indata = rgbdata.reshape( (V*H,d) )
    mmb, dst2 = clust.vq( indata, clst )
    answ = mmb.reshape( (V,H) )
    return clst, mmb

