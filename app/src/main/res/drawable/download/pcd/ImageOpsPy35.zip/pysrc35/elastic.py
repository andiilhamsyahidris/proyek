# elastic.py
# JM Kinser

import numpy as np
import warp

def ReadFiducial( inname ):
    a = open(inname).read()
    a = a.split('\n')
    N = len( a )
    if len(a[-1])<10:
        N -= 1
    mat = np.zeros( (N,2) )
    for i in range( N ):
        b = a[i].split()
        b1 = int( b[0][1:-1])
        b2 = int( b[1][:-1])
        mat[i] = b1,b2
    return mat

## get data
fidlist = ['data/feret/00130_931230_fa.txt',
           'data/feret/00130_931230_fb.txt',
           'data/feret/00141_931230_fa.txt']
def GetFidData( fidlist ):
    mats = []
    for i in range( len( fidlist )):
        mats.append( ReadFeret( fidlist[i] ))
    return mats
     
## center
def RemoveCenterBias( mats ):
    """mats
    Compute the center of the first matrix.
    Shift the rest to match this."""
    ctr1 = mats[0].mean(0) # center of first grid
    for i in range( 1, len(mats)):
        ctr = mats[i].mean(0)
        shift = ctr1 - ctr
        mats[i] += shift
    
## rotate
def RemoveRotateBias( mats ):
    """mats
    compute theta for all points in all matrices
    compute change of theta compared to first mat
    rotate"""
    N = len( mats )
    D = len( mats[0] )
    T = np.zeros( (N,D) )
    for i in range( N ):
        T[i] = np.arctan2( mats[i][:,1], mats[i][:,0] )
    # change the others
    for i in range( 1, N ):
        diff = T[0] - T[i]
        avgdiff = diff.mean()
        # rotate
        T[i] += avgdiff
        r = np.hypot( mats[i][:,0], mats[i][:,1] )
        mats[i][:,0] = r * np.cos(T[i])
        mats[i][:,1] = r * np.sin(T[i])
        

## Scale
def RemoveScaleBias( mats ):
    """mats
    compute distance to center for all
    change scales to match first grid"""
    N = len( mats )
    D = len( mats[0] )
    # get radial lengths for first grid
    R = np.hypot( mats[0][:,0],  mats[0][:,1] )
    avg = R.mean()
    # for each grid compute radial lengths, compare to average, scale
    for i in range( 1, N ):
        R = np.hypot( mats[i][:,0],  mats[i][:,1] )
        ravg = R.mean()
        scale = avg/ravg
        R *= scale
        T = np.arctan2( mats[i][:,0], mats[i][:,1] )
        mats[i][:,0] = R * np.sin( T )
        mats[i][:,1] = R * np.cos( T )

## measure distances
def GridDifference( grid1, grid2 ):
    diff = (grid1 - grid2)**2
    diff = np.sqrt(diff.sum(1))
    return diff
## total distance
