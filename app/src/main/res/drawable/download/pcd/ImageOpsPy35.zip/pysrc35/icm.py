# UCM
# Unified Cortical Model
# Only academic use of this software is allowed.  Commercial use is
# prohibited without the express written consent of the author.
#
# JM Kinser
# 17 Nov 1999
#
#  Usage:
#  net = UCM( dimension )
#  net.Iterate( input ) # input is a 2D array with values between 0 and 1
#  output = net.Y   # the pulse image for this generation
#
#  change the parameters:  net.f = newvalue; net.t1 = newvalue2; net.t2=newval3
#  To use centripetal autowaves:  net.IterateLS( input )

from numpy import zeros, greater
from shape import CurveFlow

class ICM:
    "Unified Cortical Model"
    f,t1,t2 = 0.9,0.8,20.0
    
    # constructor
    def __init__ (self,dim):
        self.F = zeros( dim,float)
        self.Y = zeros( dim,float)
        self.T = zeros( dim,float) + 0.0001
    
    def Iterate( self, stim ):
        if sum(sum(self.Y))>10:
            work = CurveFlow( self.Y)
            work = CurveFlow( work )
        else:
            work = zeros(self.Y.shape,float)
        self.F = self.f * self.F + stim + work
        self.Y = greater(self.F, self.T)
        self.T = self.t1 * self.T + self.t2 * self.Y + 0.1

            
