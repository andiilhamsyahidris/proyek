# eshape.py
# JM Kinser

import numpy as np
import matplotlib.pyplot as plt

def Shape1():
    mean = np.array((0,0))
    cov = np.array(((10,0),(0,1)))
    x,y = np.random.multivariate_normal(mean,cov,1000).T
    return x,y

def ShowMe( x,y ):
    plt.axis([-15,15,-15,15])
    plt.plot(x,y,'x')
    plt.show()

def Shape2():
    mean = np.array((0,0))
    cov = np.array(((10,0),(0,1)))
    mat = np.random.multivariate_normal(mean,cov,1000).T
    t = np.radians(45)
    rot = np.array( ((np.cos(t),-np.sin(t)),(np.sin(t),np.cos(t))))
    mat = rot.dot(mat)
    x,y = mat
    return x,y
    
def Shape3():
    mean = np.array((0,0))
    cov = np.array(((50,0),(0,1)))
    mat = np.random.multivariate_normal(mean,cov,1000).T
    t = np.radians(45)
    rot = np.array( ((np.cos(t),-np.sin(t)),(np.sin(t),np.cos(t))))
    mat = rot.dot(mat)
    x,y = mat
    return x,y

def Shape4():
    mean = np.array((0,0))
    cov = np.array(((50,0),(0,1)))
    mat = np.random.multivariate_normal(mean,cov,1000).T
    t = np.radians(45)
    rot = np.array( ((np.cos(t),-np.sin(t)),(np.sin(t),np.cos(t))))
    mat1 = rot.dot(mat)
    #
    mean = np.array((0,0))
    cov = np.array(((5,0),(0,0.1)))
    m = np.random.multivariate_normal(mean,cov,200).T
    t = np.radians(-45)
    rot = np.array( ((np.cos(t),-np.sin(t)),(np.sin(t),np.cos(t))))
    mat2 = (rot.dot(m).T - np.array((5,5))).T
    #
    mean = np.array((0,0))
    cov = np.array(((5,0),(0,0.1)))
    m = np.random.multivariate_normal(mean,cov,200).T
    t = np.radians(-45)
    rot = np.array( ((np.cos(t),-np.sin(t)),(np.sin(t),np.cos(t))))
    mat3 = (rot.dot(m).T + np.array((5,5))).T
    #
    mat = np.concatenate( (mat1,mat2,mat3),axis=1)
    x,y = mat
    return x,y

def Shape5():
    mean = np.array((0,0))
    cov = np.array(((50,0),(0,1)))
    mat = np.random.multivariate_normal(mean,cov,1000).T
    t = np.radians(45)
    rot = np.array( ((np.cos(t),-np.sin(t)),(np.sin(t),np.cos(t))))
    mat1 = rot.dot(mat)
    #
    mean = np.array((0,0))
    cov = np.array(((5,0),(0,0.1)))
    m = np.random.multivariate_normal(mean,cov,200).T
    t = np.radians(-45)
    rot = np.array( ((np.cos(t),-np.sin(t)),(np.sin(t),np.cos(t))))
    mat2 = (rot.dot(m).T - np.array((5,5))).T
    #
    mean = np.array((0,0))
    cov = np.array(((5,0),(0,0.1)))
    m = np.random.multivariate_normal(mean,cov,200).T
    t = np.radians(-45)
    rot = np.array( ((np.cos(t),-np.sin(t)),(np.sin(t),np.cos(t))))
    mat3 = (rot.dot(m).T - np.array((1,1))).T
    #
    mat = np.concatenate( (mat1,mat2,mat3),axis=1)
    x,y = mat
    return x,y

def Shape6():
    mean = np.array((0,0))
    cov = np.array(((50,0),(0,1)))
    mat = np.random.multivariate_normal(mean,cov,1000).T
    t = np.radians(45)
    rot = np.array( ((np.cos(t),-np.sin(t)),(np.sin(t),np.cos(t))))
    mat1 = rot.dot(mat)
    #
    mean = np.array((0,0))
    cov = np.array(((5,0),(0,0.1)))
    m = np.random.multivariate_normal(mean,cov,400).T
    t = np.radians(-45)
    rot = np.array( ((np.cos(t),-np.sin(t)),(np.sin(t),np.cos(t))))
    mat2 = rot.dot(m)
    #
    mat = np.concatenate( (mat1,mat2),axis=1)
    x,y = mat
    return x,y

def ExtractStats( x,y ):
    mat = np.array( (x,y))
    cv = np.cov( mat )
    evals, evecs = np.linalg.eig( cv )
    return cv, evals, evecs

    
def Metrics( orig ):
    area = (orig > 0.5).sum()
    a = nd.binary_erosion( orig )
    perim = orig-a
    perimsum = perim.sum()
    vs,hs = a.nonzero()
    mat = np.zeros( (2,len(vs)) )
    mat[0] = vs; mat[1] = hs
    evls, evcs = np.linalg.eig( np.cov( mat ) )
    eccen = evls[0]/evls[1]
    if eccen < 1: eccen = 1/ eccen
    compact = perimsum**2 / area
    return area, perimsum, eccen, compact
