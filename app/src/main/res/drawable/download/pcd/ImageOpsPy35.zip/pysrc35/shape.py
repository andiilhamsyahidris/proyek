# shape.py
# JM Kinser
# Python 3.x

import numpy as np
import scipy.ndimage as nd
import scipy.spatial as sp
import scipy.signal as ss
import rpolar

def PerimeterPoints( adata, pick=0 ):
    temp = adata > 0.5
    bdata = temp - nd.binary_erosion( temp )
    v,h = bdata.nonzero()
    mat = np.vstack((v,h)).T
    cd = sp.distance.cdist(mat,mat)
    big = cd.max()*2
    pmpts = [pick]
    k = pick
    N = len( cd )
    cd[:,k] = big
    for i in range(N-1):
        cd[k,k] = big
        x = cd[k].argmin()
        pmpts.append( x )
        cd[:,x] = big
        k = x
    return pmpts, mat

def ShowPerimPoints( vh, mat, pmpts ):
    """frame size, PerimeterPoints"""
    showme = np.zeros( vh )
    for i in range(len(pmpts)):
        v,h = mat[pmpts[i]]
        showme[v,h] = i
    return showme

def ChainLength( perimpts ):
    a = perimpts[1:] - perimpts[:-1]
    dist = np.sqrt((a**2).sum())
    return dist

def Curvature( perimpts ):
    a,b = np.gradient( perimpts )
    c,d = np.gradient( a ) 
    kt2 = c[:,0]**2 + c[:,1]**2
    return kt2

def FourierDescriptors( orig ):
    cofm = nd.center_of_mass( orig )
    vv,hh =int(cofm[0]), int(cofm[1])
    rp = rpolar.RPolar( orig, (vv,hh))
    V,H = rp.shape
    scale = 360/H
    rp = nd.zoom( rp,(1,scale))
    H = 360
    vec = np.zeros( H, complex )
    for i in range(H ):
        nz = rp[:,i].nonzero()[0]
        if len(nz)==0:
            nz = old 
        theta = np.radians( i*360./H )
        vec[i] = nz[-1]*np.cos( theta ) + 1j*nz[-1]*np.sin(theta)
        old = nz
    return vec

def CurveFlow( indata, gamma=0.75, smooth=70 ):
    adata = indata + 0.0
    bdata = adata + (ss.cspline2d(adata,smooth)*(1-adata)) > (1-gamma)
    cdata = bdata - (ss.cspline2d(bdata,smooth)<gamma)*bdata
    return cdata
